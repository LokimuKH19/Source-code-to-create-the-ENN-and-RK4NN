Copyright (C) [2024] LokimuKH19

FatigueValue_Example.xlsx: The example data of load (the torque on the main shaft) in 100s
LoadValue_Example.xls: The damage ratio of each turbine obtianed by the modified RCM
ENN.py: The source code to generate an Euler neural network for fatigue life estimation
RK4NN.py: The source code to generate a Runge-Kutta 4th-order neural network for fatigue life estimation