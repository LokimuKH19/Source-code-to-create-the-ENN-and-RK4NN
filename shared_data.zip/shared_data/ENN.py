# Copyright (C) [2024] LokimuKH19
# 时间序列分析代理模型计算加速，只负责生成模型，不负责做别的，因此不会写入主程序
import torch
import torch.nn as nn
import torch.optim as optim
import pickle
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import time


# 第n时刻
# 损伤值：直接由载荷历史数据得到yn=g(l1,...ln)，li=l(ti)
# 因此损伤值的增长只和当时多出来的数据有关，y{n+1}-y{n} = f(tn+1, l_ti, y_ti)
excel_path = "LoadValue_Example.xls"  # 每时刻的载荷值
DF_LOAD_SPINDLE = pd.read_excel(excel_path).values
excel_path = "FatigueValue_Example.xlsx"  # 通过之前提出的物理统计学方法算出的疲劳损伤值
DF_DMG_SPINDLE = pd.read_excel(excel_path).values

# 切分数据(从2起算，为了刻画0附近特征采取前10s的数据训练一组，后90s的数据再训练一组，然后俩模型合计一下)
# 前50s
T = DF_LOAD_SPINDLE[1:51, 0]
LOAD = DF_LOAD_SPINDLE[1:51, 1:]
DMG = DF_DMG_SPINDLE[:50, 1:]

# 后50s
'''
T = DF_LOAD_SPINDLE[51:, 0]
LOAD = DF_LOAD_SPINDLE[51:, 1:]
DMG = DF_DMG_SPINDLE[50:-1, 1:]
'''

# 计算损伤对数增量，之后从t=2起算
DDMG = np.diff(DF_DMG_SPINDLE[:, 1:], axis=0)
DDMG[np.abs(DDMG) > 10e-11] = 0

# 把T扩展
T = np.tile(T, (LOAD.shape[1], 1)).T  # 创建 n 行，1 列的复制
# 拼接训练集和测试集
split = 80
Train_T, Train_LOAD, Train_DMG, Train_DDMG = T[:, :split], LOAD[:, :split], DMG[:, :split], DDMG[:, :split]
Test_T, Test_LOAD, Test_DMG, Test_DDMG = T[:, split:], LOAD[:, split:], DMG[:, split:], DDMG[:, split:]
# 将它们改成列向量并进行拼接
X_train = np.hstack([Train_T.reshape(-1, 1), Train_LOAD.reshape(-1, 1), Train_DMG.reshape(-1, 1)])
X_test = np.hstack([Test_T.reshape(-1, 1), Test_LOAD.reshape(-1, 1), Test_DMG.reshape(-1, 1)])
y_train = np.hstack([Train_DDMG.reshape(-1, 1)])
y_test = np.hstack([Test_DDMG.reshape(-1, 1)])
plt.plot(np.vstack([y_train, y_test]))
plt.show()
# 计算全局最大最小值
MAX_X = np.max(np.vstack([X_train, X_test]), axis=0)
MAX_y = np.max(np.vstack([y_train, y_test]), axis=0)
MIN_X = np.min(np.vstack([X_train, X_test]), axis=0)
MIN_y = np.min(np.vstack([y_train, y_test]), axis=0)
X_train_standard = (X_train-MIN_X)/(MAX_X-MIN_X)
y_train_standard = (y_train-MIN_y)/(MAX_y-MIN_y)
X_test_standard = (X_test-MIN_X)/(MAX_X-MIN_X)
y_test_standard = (y_test-MIN_y)/(MAX_y-MIN_y)
print(MIN_X,MAX_X,MIN_y,MAX_y)
# 打乱训练集和测试集合
row_indices_train, row_indices_test = np.arange(X_train_standard.shape[0]), np.arange(X_test_standard.shape[0])
np.random.shuffle(row_indices_train)
np.random.shuffle(row_indices_test)
X_train_standard = X_train_standard[row_indices_train]
y_train_standard = y_train_standard[row_indices_train]
X_test_standard = X_test_standard[row_indices_test]
y_test_standard = y_test_standard[row_indices_test]
# 确保所有数据都是数值类型
X_train_standard = X_train_standard.astype(np.float32)
y_train_standard = y_train_standard.astype(np.float32)
X_test_standard = X_test_standard.astype(np.float32)
y_test_standard = y_test_standard.astype(np.float32)


# 搭建网络模型
class PINN(nn.Module):
    def __init__(self):
        super(PINN, self).__init__()
        # 搭建网络
        self.net = nn.Sequential(
            nn.Linear(3, 20),
            nn.Tanh(),
            nn.Linear(20, 20),
            nn.Tanh(),
            nn.Linear(20, 1)
        )
        # 基础设置
        self.device = 'cuda'    # cpu或者cuda(前提是要有)
        self.net.to(self.device)
        self.learning_rate = 0.0001    # 学习率

        # 其他的训练数据
        self.optimizer = optim.Adam(self.parameters(), lr=self.learning_rate)    # 优化器
        self.mse = torch.nn.MSELoss(reduction='mean')   # MSE损失函数
        self.loss = None    # 用于承接损失
        # loss历史记录
        self.train_losses = []
        self.test_losses = []

    # 加载数据，将数据转变为float32类型
    def load_data(self, x, requires_grad=True):
        data32 = torch.tensor(x, requires_grad=requires_grad, dtype=torch.float32)
        return data32.to(self.device)

    # 从设备读取数据
    def read_data(self, data):
        tmp_data = data.detach().cpu().numpy()
        if np.isnan(tmp_data).any():
            raise Exception
        return tmp_data

    # 前向传播， xn=[tn, ln, yn-1], 为隐式欧拉法
    def forward(self, x):
        # 原始网络输出 f(t_n, l_n, y_n-1)
        x = x.float()
        return self.net(x)

    # 训练模型
    def update(self, X_train, y_train, X_test, y_test, epochs):
        # 初始化更新准备
        self.optimizer.zero_grad()
        self.loss = torch.tensor(0.0, dtype=torch.float64).to(self.device)
        self.loss.requires_grad_()
        # 将训练数据转换为Tensor
        X_train_tensor = self.load_data(X_train)
        y_train_tensor = self.load_data(y_train)
        X_test_tensor, y_test_tensor = self.load_data(X_test), self.load_data(y_test)

        # 训练循环
        for epoch in range(epochs):
            # 前向传播
            output = self.forward(X_train_tensor)
            output_test = self.forward(X_test_tensor)
            # 计算损失
            self.loss = self.mse(output, y_train_tensor)
            loss_test = self.mse(output_test, y_test_tensor)
            # 反向传播
            self.optimizer.zero_grad()
            self.loss.backward()
            self.optimizer.step()
            print(f'{epoch+1}: Train Loss: {self.loss}, Test Loss{loss_test}')
            self.train_losses.append(self.loss)
            self.test_losses.append(loss_test)
        # 训练结束，返回最终的损失
        return self.loss.item()

    # 测试模型
    def test(self, X_test, y_test):
        # 将测试数据转换为Tensor
        X_test_tensor = self.load_data(X_test, requires_grad=False)
        y_test_tensor = self.load_data(y_test, requires_grad=False)
        # 测试模式
        with torch.no_grad():
            # 前向传播
            output = self.forward(X_test_tensor)
            # 计算测试损失
            test_loss = self.mse(output, y_test_tensor)
        return test_loss.item(), output


# 保存模型
def save_model(mod, path):
    with open(path, "wb") as file:
        pickle.dump(mod, file)


if __name__ == '__main__':
    # 训练模型
    model = PINN()
    epochs = 6000  # 可以根据需要调整epoch的数量
    final_loss = model.update(X_train_standard, y_train_standard, X_test_standard, y_test_standard, epochs)
    save_model(model, "ENN.pkl")
    with open('ENN.pkl', 'rb') as file:
        model = pickle.load(file)
    plt.plot([loss.cpu().detach().numpy() for loss in model.train_losses])
    plt.plot([loss.cpu().detach().numpy() for loss in model.test_losses], '--')
    plt.show()
    start = time.time()
    test_loss, test_output = model.test(X_test_standard, y_test_standard)
    print(test_loss, test_output)
    end = time.time()
    print(end-start)
